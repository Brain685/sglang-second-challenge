#!/usr/bin/env python3
"""HW2 Task 1: Measure prefix caching effect in SGLang."""

import json
import time
import asyncio
import argparse
import statistics
from pathlib import Path

import aiohttp

BASE_URL = "http://127.0.0.1:30000"
FLUSH_URL = f"{BASE_URL}/flush_cache"
GENERATE_URL = f"{BASE_URL}/generate"

NUM_REQUESTS = 32
MAX_CONCURRENCY = 8
MAX_NEW_TOKENS = 16
TEMPERATURE = 0.0
IGNORE_EOS = True
SAMPLING_SEED = 2026

SHARED_PREFIX_LEN = 2048
SUFFIX_LEN = 64
DISPERSED_LEN = 2112


def build_shared_prefix(seed=1234):
    import random
    rng = random.Random(seed)
    return [rng.randint(1000, 30000) for _ in range(SHARED_PREFIX_LEN)]


def build_shared_suffix(req_id):
    import random
    rng = random.Random(10000 + req_id)
    return [rng.randint(1000, 30000) for _ in range(SUFFIX_LEN)]


def build_dispersed_input(req_id):
    import random
    rng = random.Random(20000 + req_id)
    first = 50000 + req_id
    rest = [rng.randint(1000, 30000) for _ in range(DISPERSED_LEN - 1)]
    return [first] + rest


async def flush_cache(session):
    async with session.post(FLUSH_URL) as r:
        return await r.text()


async def send_request(session, semaphore, input_ids, req_id):
    payload = {
        "input_ids": input_ids,
        "sampling_params": {
            "temperature": TEMPERATURE,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": IGNORE_EOS,
        },
        "sampling_seed": SAMPLING_SEED,
        "stream": False,
    }
    async with semaphore:
        t0 = time.perf_counter()
        try:
            async with session.post(GENERATE_URL, json=payload) as r:
                resp = await r.json()
                elapsed = time.perf_counter() - t0
                meta = resp.get("meta_info", {})
                return {
                    "req_id": req_id,
                    "status": r.status,
                    "prompt_tokens": meta.get("prompt_tokens"),
                    "completion_tokens": meta.get("completion_tokens"),
                    "cached_tokens": meta.get("cached_tokens", 0),
                    "ttft": meta.get("ttft"),
                    "e2e_latency": elapsed,
                }
        except Exception as e:
            return {
                "req_id": req_id,
                "status": "error",
                "error": str(e),
                "e2e_latency": time.perf_counter() - t0,
            }


async def run_group(group_name, input_builder, out_dir, warmup=True):
    Path(out_dir).mkdir(parents=True, exist_ok=True)

    async with aiohttp.ClientSession() as session:
        print(f"[{group_name}] Flushing cache ...")
        await flush_cache(session)

        if warmup:
            print(f"[{group_name}] Sending warmup request ...")
            warmup_input = build_shared_prefix() + [999] * SUFFIX_LEN
            await send_request(session, asyncio.Semaphore(1),
                               warmup_input, req_id=-1)
            print(f"[{group_name}] Warmup done.")

        print(f"[{group_name}] Sending {NUM_REQUESTS} requests "
              f"(concurrency={MAX_CONCURRENCY}) ...")
        semaphore = asyncio.Semaphore(MAX_CONCURRENCY)
        tasks = [
            send_request(session, semaphore, input_builder(i), i)
            for i in range(NUM_REQUESTS)
        ]
        results = await asyncio.gather(*tasks)

    out_jsonl = Path(out_dir) / "per_request.jsonl"
    with open(out_jsonl, "w") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"[{group_name}] Per-request results saved to {out_jsonl}")

    summary = summarize(group_name, results)
    out_summary = Path(out_dir) / "summary.json"
    with open(out_summary, "w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f"[{group_name}] Summary saved to {out_summary}")
    print(f"[{group_name}] Summary: {json.dumps(summary, ensure_ascii=False)}")
    return summary


def percentile(values, p):
    if not values:
        return None
    s = sorted(values)
    k = (len(s) - 1) * p / 100.0
    f = int(k)
    c = min(f + 1, len(s) - 1)
    if f == c:
        return s[f]
    return s[f] + (s[c] - s[f]) * (k - f)


def summarize(group_name, results):
    ok = [r for r in results if r.get("status") == 200]
    total = len(results)
    success = len(ok)

    prompt_tokens = [r["prompt_tokens"] for r in ok if r.get("prompt_tokens")]
    cached_tokens = [r.get("cached_tokens", 0) for r in ok]
    completion_tokens = [r["completion_tokens"] for r in ok if r.get("completion_tokens")]
    ttft = [r["ttft"] for r in ok if r.get("ttft") is not None]
    e2e = [r["e2e_latency"] for r in ok if r.get("e2e_latency") is not None]

    total_prompt = sum(prompt_tokens)
    total_cached = sum(cached_tokens)
    total_prefill = total_prompt - total_cached
    total_out = sum(completion_tokens)

    hit_rate = total_cached / total_prompt if total_prompt else 0.0

    return {
        "group": group_name,
        "num_requests": total,
        "success_count": success,
        "success_rate": success / total if total else 0.0,
        "total_prompt_tokens": total_prompt,
        "total_cached_tokens": total_cached,
        "total_prefill_tokens": total_prefill,
        "total_output_tokens": total_out,
        "cache_hit_rate": hit_rate,
        "ttft_p50_s": percentile(ttft, 50),
        "ttft_p95_s": percentile(ttft, 95),
        "e2e_p50_s": percentile(e2e, 50),
        "e2e_p95_s": percentile(e2e, 95),
        "ttft_mean_s": statistics.mean(ttft) if ttft else None,
        "e2e_mean_s": statistics.mean(e2e) if e2e else None,
    }


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-root", default="/root/hw2/results/target1")
    parser.add_argument("--group", choices=["shared", "dispersed", "both"],
                        default="both")
    args = parser.parse_args()

    if args.group in ("shared", "both"):
        await run_group(
            "shared_prefix",
            lambda i: build_shared_prefix() + build_shared_suffix(i),
            f"{args.out_root}/shared_prefix",
            warmup=True,
        )
    if args.group in ("dispersed", "both"):
        await run_group(
            "dispersed_prefix",
            lambda i: build_dispersed_input(i),
            f"{args.out_root}/dispersed_prefix",
            warmup=False,
        )


if __name__ == "__main__":
    asyncio.run(main())
