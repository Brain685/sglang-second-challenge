# HW2 第二次挑战

## 硬件与软件版本

| 项目 | 版本 |
|---|---|
| GPU | NVIDIA GeForce RTX 3080 Ti（12 GB） |
| 操作系统 | Ubuntu（AutoDL 容器） |
| CUDA | 13.0（通过 pip 安装 nvidia-cuda-nvcc==13.0.88） |
| Python | 3.10 |
| SGLang | 0.5.14 |
| Ray | 2.56.0 |
| 模型 | Qwen/Qwen3-0.6B |

## 安装方法

```bash
pip install "sglang==0.5.14"
pip install "nvidia-cuda-nvcc==13.0.88" "nvidia-nvvm==13.0.88" --force-reinstall
pip install "nvidia-cuda-runtime==13.0.88" "nvidia-cuda-crt==13.0.88" --force-reinstall
pip install "nvidia-cuda-cccl==13.0.85" --force-reinstall
pip install aiohttp
```

模型下载：

```bash
huggingface-cli download Qwen/Qwen3-0.6B --local-dir ~/Qwen3-0.6B
```

## 启动命令

```bash
export CUDA_HOME=/root/miniconda3/lib/python3.10/site-packages/nvidia/cu13
export CUDA_PATH=$CUDA_HOME
export FLASHINFER_NVCC=$CUDA_HOME/bin/nvcc
export PATH=$CUDA_HOME/bin:$PATH
export LIBRARY_PATH=$CUDA_HOME/lib:$LIBRARY_PATH
export LD_LIBRARY_PATH=$CUDA_HOME/lib:$LD_LIBRARY_PATH

python -m sglang.launch_server --model ~/Qwen3-0.6B --host 0.0.0.0 --port 30000
```

## 任务一回放命令

```bash
cd src/target1
python bench_prefix_cache.py --group both
```

脚本会自动：

1. 调用 /flush_cache 清空缓存
2. 共享前缀组先发 1 条预热请求
3. 发送 32 条请求（最大并发 8）
4. 记录每条请求的 cached_tokens、TTFT、E2E 延迟
5. 结果保存到 results/target1/{shared_prefix,dispersed_prefix}/

## 脚本用途

| 脚本 | 用途 |
|---|---|
| src/target1/bench_prefix_cache.py | 任务一实验脚本，构造两组负载并发送请求，记录 cached_tokens、TTFT、E2E 延迟等指标。 |

## 结果目录与报告表格的对应关系

| 报告位置 | 对应结果文件 |
|---|---|
| 报告任务一 1.2 对照表 | results/target1/shared_prefix/summary.json |
| 报告任务一 1.2 对照表 | results/target1/dispersed_prefix/summary.json |
| 报告任务一逐请求明细 | results/target1/*/per_request.jsonl |

## 目录结构

```
HW2-林仪聪/
├── README.md
├── report.pdf
├── AI使用说明情况（第二次挑战）.pdf
├── 第二次挑战作业感受.pdf
├── src/
│   └── target1/
│       └── bench_prefix_cache.py
└── results/
    └── target1/
        ├── shared_prefix/
        │   ├── summary.json
        │   └── per_request.jsonl
        └── dispersed_prefix/
            ├── summary.json
            └── per_request.jsonl
```
